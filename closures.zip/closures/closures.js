//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Closures

//A closure is the combination of a function and the lexical environment within which that function was declared. 

//What is a closure?
// A closure is an inner function that has access to the outer (enclosing) function’s variables—scope chain. The closure has three scope chains: it has access to its own scope (variables defined between its curly brackets), it has access to the outer function’s variables, and it has access to the global variables.
// The inner function has access not only to the outer function’s variables, but also to the outer function’s parameters.

// global scope(this also called closure)
//ex1
// var passed = 3;

// function myFunc() {
//     function myFunc2(){
//         console.log(passed);
//     } 

//     myFunc2();
// }
// console.log(myFunc());
// note: 1.If u declare passed as global varibale other functions also can change value so its not good parctice even though it is a closure better to use below example

//lexical environment
//ex2
// function init() {

//     var name = 'mozilla';// name is a local variable created by init
//     function displyName(){ //// displayName() is the inner function, a closure
//         console.log(name);// use variable declared in the parent function 
//     }

//     displyName();
// }
// init();
//note
//1. why closure -->if u declare name variable outside init function its value can be changed by other functions bcas it is created as global variable to avoid this problem we used closure. closure will have access to outer functions varible and also u can make name as local varible so that no other can have access to except inner functions which are called closures

//closure 
//ex3
function makeFun(){

    var name = 'mozilla';
    function displayName(){
        console.log(name);
    }

    return displayName;//The return statement stops the execution of a function and returns a value from that function.
    //return displayName(); calls the function displayName(), and returns its result.
    //return displayName; returns a reference to the function displayName, which you can store in a variable to call later.

    //or

    //When you return b, it is just a reference to function b, but not being executed at this time.
    //When you return b(), you're executing the function and returning its value.

    // if u return with() it throws an error    
    // return displayName();//Uncaught TypeError: myFunc is not a function
}

var myFunc = makeFun();
myFunc();

//Note Running this code has exactly the same effect as the above example of the init() function above; what's different — and interesting — is that the displayName() inner function is returned from the outer function before being executed.

//Here's a slightly more interesting example — a makeAdder function:
function makeAdder(x) {
    return function(y) {
      return x + y;
    };
  }
  
  var add5 = makeAdder(5);
  var add10 = makeAdder(10);
  
  console.log(add5(2));  // 7
  console.log(add10(2)); // 12

  // In essence, makeAdder is a function factory — it creates functions which can add a specific value to their argument. In the above example we use our function factory to create two new functions — one that adds 5 to its argument, and one that adds 10.

    // add5 and add10 are both closures. They share the same function body definition, but store different lexical environments. In add5's lexical environment, x is 5, while in the lexical environment for add10, x is 10.

    //Practical closures
// open above given link