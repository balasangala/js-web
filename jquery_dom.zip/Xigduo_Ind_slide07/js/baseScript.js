
$(document).ready(function(){
	"use strict";

$("#mainContainer").swipe({
        swipe: function(event, direction, distance, duration, fingerCount) {
            //This only fires when the user swipes left
            // var closestViewport = $(event.target).closest('.content');
			console.log(direction);
			if (!$(event.target).hasClass('dragable_icon') && !$(event.target).hasClass('ui-draggable') && !$(event.target).hasClass('noSwipe')) {
				if (direction === 'left') {
                	  //alert(4);
                      document.location="veeva:gotoSlide(Xigduo_Ind_slide08.zip,FEB2018_iDA)";
                       
                }else if (direction === 'right') {
                    //alert(5);
					  document.location="veeva:gotoSlide(Xigduo_Ind_slide06.zip,FEB2018_iDA)";
                }
            }

        }
    });

});
