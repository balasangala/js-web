var presentation_id_veeva;
/*array having informqations of links yo be done*/
var page_details={
				"btnlink1":
				{"zip_name": "TAG_CH_Slide02_German.zip", "presentation_Id": "Tagrisso_CH_German"},
				"btnlink2":
				{"zip_name": "TAG_CH_Slide23_German.zip", "presentation_Id": "Tagrisso_CH_German"},
				"btnlink3":
				{"zip_name": "TAG_CH_Slide02_German.zip", "presentation_Id": "Tagrisso_CH_German"}
				
				
				
		};
	/*To obtain the presentation name */
	function getPresentationID(){
		com.veeva.clm.getDataForCurrentObject("Presentation","Presentation_Id_vod__c", presentation_ID_result);
	}
		
	function presentation_ID_result(){
		var presentation_id_1=JSON.stringify(result);
		try{
		presentation_id_veeva=eval("(" + presentation_id_1 + ")").Presentation.Presentation_Id_vod__c.split(':')}
		catch(err){presentation_id_veeva=presentation_id_1.Presentation.Presentation_Id_vod__c.split(':');}
	}
	function pageLink(pageName){
		if((page_details[pageName]["presentation_Id"]==""||typeof page_details[pageName]["presentation_Id"] == "undefined")){
			presentation_id_final=presentation_id_veeva;	
		}else{
			presentation_id_final = page_details[pageName]["presentation_Id"];
		}
		com.veeva.clm.gotoSlide(''+page_details[pageName]["zip_name"],presentation_id_final);
		//alert(page_details[pageName]["zip_name"]);
	}
