var flag = true;
var clickHandler = "click";
 if ('ontouchstart' in document.documentElement) {
        clickHandler = "tap";
    }
$(document).ready(function () {
	"use strict";
	$("body").bind("touchmove", function (e) {
		e.preventDefault();
	});


	setTimeout(function () {
		$("#back").css("visibility", "hidden");
	}, 300);
	setTimeout(function () {
		$("#mainContainer").css("visibility", "visible");
	}, 300);
	
	
   	$('#home,#patient_profile,#next_btn,#prev_btn,#faq').bind('tap', function(){
	window.location.href=$(this).attr('goto');
	});
	
	$('#ref').bind('tap', function(){
		$('#ref_active,#ref_container,#overlay').show();
	});
	
	$('.close').bind('tap', function(){
		$('#ref_active,#ref_container,#overlay').hide();
	});
	
	$('#pi').bind('tap', function(){
		$('#pi_active,#pi_container,#overlay').show();
	});
	
	$('.close').bind('tap', function(){
		$('#pi_active,#pi_container,#overlay').hide();
	});
	
	$("<div/>").attr('id','grph').appendTo('#mainContainer').css({'background-image' : 'url(images/graph1.jpg)','width' : '382px','height' : '297px', 'position' : 'absolute', 'top' : '287px', 'left' : '505px','background-size' : 'contain', 'background-repeat' : 'no-repeat'});
	
	$("<div/>").attr('id','tabs').appendTo('#mainContainer').css({'background-image' : 'url(images/tab1.png)','width' : '323px','height' : '33px', 'position' : 'absolute', 'top' : '615px', 'left' : '566px','background-size' : 'contain', 'background-repeat' : 'no-repeat'});
	
	$("<div/>").attr('id','hba1c').appendTo('#mainContainer').css({ 'width' : '101px','height' : '33px', 'position' : 'absolute', 'top' : '615px', 'left' : '566px' }); 
	$("<div/>").attr('id','weight').appendTo('#mainContainer').css({ 'width' : '101px','height' : '33px', 'position' : 'absolute', 'top' : '615px', 'left' : '677px' }); 
	$("<div/>").attr('id','bp').appendTo('#mainContainer').css({ 'width' : '101px','height' : '33px', 'position' : 'absolute', 'top' : '615px', 'left' : '788px' }); 
	
	//simple js	
	$('#hba1c').bind('tap', function(){
		
		$('#grph').css({'background-image' : 'url(images/graph1.jpg)','width' : '382px','height' : '297px', 'top' : '287px', 'left' : '505px' });
		$('#tabs').css({'background-image' : 'url(images/tab1.png)'});
		
		
	});
	$('#weight').bind('tap', function(){
		
		$('#grph').css({'background-image' : 'url(images/graph2.jpg)','width' : '388px','height' : '317px', 'top' : '277px', 'left' : '498px' });
		$('#tabs').css({'background-image' : 'url(images/tab2.png)'});
			
	});
	$('#bp').bind('tap', function(){
		
		$('#grph').css({'background-image' : 'url(images/graph3.jpg)','width' : '388px','height' : '315px' , 'top' : '277px', 'left' : '498px'});
		$('#tabs').css({'background-image' : 'url(images/tab3.png)'});
	});
	

	

		//	bottom navigation
	$('#mainContainer').bind('tap', function () {
		if (flag) {
			var anmV = parseInt($("#nav_bar")[0].style.bottom.split(' ')[0]);
			if ((anmV === 0)) {
				$("#nav_bar").animate({
					'bottom': '-50px',
					'opacity': '0'
				}, 150);
				$("#arrow2").hide();
				$(".arrow").show();
			}
		} else {
			flag = false;
		}
	});
	$(".arrow").bind('tap', function () {
		$("#nav_bar").animate({
			'bottom': '0px',
			'opacity': '1'
		}, 150);
		$("#arrow2").show();
		$(".arrow").hide();
	});

	
});


