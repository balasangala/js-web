//constructor
//u can create many objects by just creating constructor 
function Book(title2, author, year){
	this.title1 = title2;
	this.author = author;
	this.year = year;
	//adding property
	this.country = "india";
	//adding method
	this.getSummary =  function(){
		return `${this.title1} was written by ${this.author} in ${this.year} from ${this.country}`;

	}
}

//creating objects
var book1 = new Book("Book1", "balu", "2015");
var book2 = new Book("Book2", "balu2", "2016");
var book3 = new Book("Book3", "balu3", "2017");
// var book4 = new Book("Book4", "balu4", "2018");
// console.log(book1);
// console.log(book1.title1);
// console.log(book2.year);

//You cannot add a new property to an object constructor the same way you add a new property to an existing object:
//To add a new property to a constructor, you must add it to the constructor function:
// console.log(book1.country);
// console.log(book1.title1);

//You cannot add a new method to an object constructor the same way you add a new method to an existing object.
//Adding methods to an object must be done inside the constructor function

// console.log(book1.getSummary());
// console.log(book2.getSummary());
// console.log(book3.getSummary());

