// console.log(window);
// console.log(window.navigator);
// console.log(navigator.appVersion);
// console.log(window.screen);
// console.log(window.alert);
// console.log(alert(1));
// console.log(window.history);
// console.log(history.length);
// console.log(navigator.clipboard);

//object literals

var book1 = {
	title:"Book one",
	author:"balu",
	year:2018,
	//method
	getSummary: function(){
		//return this.title +" was written by "+ this.author;
		//ES6 Syntaxt for above
		return `${this.title} was written by ${this.author} in ${this.year} in ${this.language}`;
	}
	
}

// console.log(book1);
//accessing property
// console.log(book1.title);//Book one
//know all values in aobject
// console.log(Object.values(book1));
// document.write(Object.values(book1));
// console.log(Object.keys(book1));
//accessing the method in aject
// console.log(book1.getSummary());

// adding property to existing object
 book1.language = "telugu";
// console.log(book1);
// console.log(book1.language);
// console.log(book1.getSummary());


//adding method to existing object
book1.addMethod = function(){
	return `${this.title} was written by ${this.author}`;
}

console.log(book1.addMethod());

//you can create only one object by using this method
//to create more methods of same type use constructor