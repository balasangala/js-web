//functions in arrays
//many ways to use functions in arrays

// var arr = ["str1", "str2", "str3", myfunc];

// function myfunc(){
// 	return arr[3] = "str4";
// }
// document.write(arr[3]());//str4

/* var arr = ["str1", "str2", "str3", myfunc];

function myfunc(newEle){
	return newEle = "str4";
}
document.write(arr[3]());//str4 */

/*  var arr = ["str1", "str2", "str3", myfunc];

function myfunc(newEle){
	return newEle;
}
document.write(arr[3]("str4"));//str4 */


/*  var arr = ["str1", "str2", "str3", function(){
	var newEle = "str4";

	return newEle;
}];
console.log(arr[3]());//str4 */

/* var arr = ["str1", "str2", "str3", function(newEle){
	

 	return newEle = "str4";
}];
 console.log(arr[3]());//str4 */

 //objects in arrays
 //array elements can be accessed by index position
 //objects can be accessed by referring name
/* var arr = [{fname:"balu", lname:"sang"}, {age:24, year:1992},{age:30, year:1998},{age:35, year:2005}]
console.log(arr);
for(var i=0; i<arr.length; i++){
	if( arr[i].age >25){

		document.write(arr[i].age+" ");
		}
 }//30 35 */

 

