$(document).ready(function() {

	"use strict";

    $("body").bind('touchmove', function(event) {
        event.preventDefault();
    });   

    $("#wrapper").swipe({

        swipe: function(event, direction, distance, duration, fingerCount) {

            if (!$(event.target).hasClass('noSwipe')) {

               if (direction == 'left') {                  
                    document.location="veeva:nextSlide()";  
				  // console.log("left");
				 

                } else if (direction == 'right') {
                    //alert(direction);
                    document.location="veeva:prevSlide()";    
                } 
            }
            event.stopImmediatePropagation();
            event.preventDefault();
        },
        threshold: 100
    });
});