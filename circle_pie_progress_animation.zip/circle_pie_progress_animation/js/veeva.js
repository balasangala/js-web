/*  VEEVA SPECIFIC FUNCTIONALITY + HELPERS
Phil Higgs - Ogilvy DigitalHealth 2014
v1.0
*/
! function(veeva, $, undefined) {
    function loadFile(a, b) { debugTiming && console.time("loadFile");
        var c = $.ajax({ type: "GET", url: a, cache: !0, dataType: "text", async: !1 }).responseText;
        return b && (c = c.replace(/\r?\n|\r|\t|\v|\f/g, "")), debugTiming && console.timeEnd("loadFile"), c }

    function isTouchDevice() {
        return "ontouchend" in document }

    function getNavDirections() {
        var a = { left: currentPageIdx > 0, previous: currentPageIdx > 0, right: currentPageIdx < pages.length - 1, next: currentPageIdx < pages.length - 1, up: swipeType == veeva.swipeTypes.VERTICAL && currentSubPageIdx >= 0, down: swipeType == veeva.swipeTypes.VERTICAL && currentSubPageIdx < subpages.length - 1 };
        return a }

    function processDirection(a) {
        var b = 0,
            c = 0,
            d = "";
        if ("left" == a || "up" == a ? b = 1 : ("right" == a || "down" == a) && (b = -1), swipeType == veeva.swipeTypes.DEFAULT || swipeType == veeva.swipeTypes.VERTICAL && ("left" == a || "right" == a)) {
            if (c = currentPageIdx + b, 0 > c || c >= pages.length) return;
            d = pages[c] } else {
            if (c = currentSubPageIdx + b, c >= subpages.length) return;
            d = 0 > c ? getDefaultKeyMessagePage(veeva.currentKeyMessage) : subpages[c] }
        veeva.slideTransitions ? (transitionClassExit = a, "left" == a ? transitionClassEntrance = "right" : "right" == a ? transitionClassEntrance = "left" : "up" == a ? transitionClassEntrance = "down" : "down" == a && (transitionClassEntrance = "up")) : transitionClassEntrance = transitionClassExit = "", processLink(d) }

    function AddHooks(selector) { debugTiming && console.time("AddHooks"), $(selector + " [data-clickstream]").each(function() {
            var $this = $(this);
            $this.attr("onclick") && $this.attr("data-onclick", $this.attr("onclick")).removeAttr("onclick"), $this.on(clickEvent, function(e) { $(this).attr("data-onclick") && eval($(this).attr("data-onclick")), e.preventDefault(), e.stopPropagation(), (veeva.runningOnVeeva || veeva.debug) && saveClickStreamData($(this).attr("data-clickstream")) }) }), $(selector + " a[href],[data-href]").on(clickEvent, function(a) { veeva.runningOnVeeva && $(this).trigger("onclick").removeAttr("onclick").unbind(clickEvent), a.preventDefault();
            var b = $(this).is("a") ? $(this).attr("href") : $(this).attr("data-href");
            processLink(b) }), veeva.runningOnVeeva && $(selector + " [onclick]").on(clickEvent, function(a) { $(this).trigger("onclick"), a.preventDefault(), a.stopPropagation() }), debugTiming && console.timeEnd("AddHooks") }

    function processLink(a) {
        if (debugTiming && console.time("processLink"), a != veeva.currentPage || veeva.allowSamePageReload) {
            var b = getKeyMessage(a);
            if (null !== b) {
                var c = a,
                    d = getKeyMessageObject(a);
                b != veeva.currentKeyMessage && (d.maincontent[0].pageUrl != a && veeva.runningOnVeeva && sessionStorage.setItem(ssKey, a), veeva.runningOnVeeva && (c = "veeva:gotoSlide(" + b + ")")), veeva.debug && showDebug("[NAVIGATION]\r\nGoing to new url: " + c);
                var e = whichTransitionEvent();
                $app.on(e, function(a) { a.stopPropagation(), $(this).off(e), document.location = c }), veeva.transitions ? ("" != transitionClassEntrance && sessionStorage.setItem(tceKey, transitionClassEntrance), "" != transitionClassExit ? $app.attr("class", transitionClassExit) : $app.removeClass("active")) : $app.trigger(e), null != veeva.onLeave && veeva.onLeave(a, d.package), debugTiming && console.timeEnd("processLink") } } }

    function whichTransitionEvent() {
        var a, b = document.createElement("fakeelement"),
            c = { transition: "transitionend", OTransition: "oTransitionEnd", MozTransition: "transitionend", WebkitTransition: "webkitTransitionEnd" };
        for (a in c)
            if (b.style[a] !== undefined) return c[a] }

    function setupPages() { debugTiming && console.time("setupPages");
        for (var a = veevaConfig.keyMessages, b = new Array, c = new Array, d = new Array, e = !1, f = 0, g = a.length; g > f; f++) {
            var h = a[f].package;
            d.push(h);
            for (var i = 0, j = a[f].maincontent.length; j > i; i++) 1 == a[f].maincontent[i].navVertical ? (veeva.currentKeyMessage == h && c.push(a[f].maincontent[i].pageUrl), a[f].maincontent[f].navVertical && (e = !0)) : b.push(a[f].maincontent[i].pageUrl) }
        pages = b, subpages = c, keymessages = d, veeva.debug && showDebug("[NAVIGATION]\r\npages: " + pages + "\r\nsubpages: " + subpages + "\r\nkeymessages: " + keymessages), e && (swipeType = veeva.swipeTypes.VERTICAL), veeva.debug && showDebug("[NAVIGATION]\r\nswipeType set to: " + swipeType), debugTiming && console.timeEnd("setupPages") }

    function getPageIndex(a) {
        for (var b = 0, c = pages.length; c > b; b++)
            if (pages[b] == a) return b;
        return 0 }

    function getKeyMessage(a) {
        for (var b = veevaConfig.keyMessages, c = 0, d = b.length; d > c; c++)
            for (var e = b[c].package, f = 0, g = b[c].maincontent.length; g > f; f++)
                if (b[c].maincontent[f].pageUrl == a) return e;
        return veeva.debug && showDebug("[*!WARNING!*]\r\n'" + a + "' has not been found in the veevaConfig file [keyMessages] section. Please ensure it is added to a keymessage."), null }

    function getDefaultKeyMessagePage(a) {
        for (var b = veevaConfig.keyMessages, c = 0, d = b.length; d > c; c++) {
            var e = b[c].package;
            if (e == a) return b[c].maincontent[0].pageUrl }
        return veeva.currentPage }

    function getPackageDefaultPage(a) {
        for (var b = veevaConfig.keyMessages, c = 0, d = b.length; d > c; c++) {
            var e = b[c].package;
            if (e == a) return b[c].maincontent[0].pageUrl }
        return "" }

    function getKeyMessageObject(a) {
        for (var b = veevaConfig.keyMessages, c = 0, d = b.length; d > c; c++) { b[c].package;
            for (var f = 0, g = b[c].maincontent.length; g > f; f++)
                if (b[c].maincontent[f].pageUrl == a) return b[c] }
        return null }

    function processPartials(selector) { debugTiming && console.time("processPartials"), $(selector + " [data-partial]").each(function() {
            var $this = $(this),
                id = $this.attr("data-partial"),
                ex = $this.is("[data-partial-onload]") ? $this.attr("data-partial-onload") : "",
                rp = $this.is("[data-partial-replace]") ? $this.attr("data-partial-replace") : "false";
            for (var k1 in veevaConfig.partials)
                if (veevaConfig.partials[k1].id == id) { "false" == rp ? $this.html(veevaConfig.partials[k1].content).removeAttr("data-partial") : $this.replaceWith(veevaConfig.partials[k1].content), veevaConfig.partials[k1].content.indexOf("data-partial") >= 0 && processPartials(selector), "" != ex && eval(ex), $.each($this[0].attributes, function(a, b) {
                        var c = b.name;
                        if ("data-partial-content-" == c.slice(0, "data-partial-content-".length)) {
                            var d = b.value;
                            c = c.substr("data-partial-content-".length), $("#" + c).html(d) } else if ("data-partial-class-" == c.slice(0, "data-partial-class-".length)) {
                            var d = b.value;
                            c = c.substr("data-partial-class-".length), $("#" + c).addClass(d) } });
                    break } }), debugTiming && console.timeEnd("processPartials") }

    function processTracking(a, b) { debugTiming && console.time("processTracking");
        for (var c = veevaConfig.tracking, d = 0, e = c.length; e > d; d++)
            if ("any" == c[d].page || c[d].page == b)
                for (var f = 0, g = c[d].clickstreams.length; g > f; f++) {
                    var h = c[d].clickstreams[f].selector,
                        i = c[d].clickstreams[f].data,
                        j = c[d].clickstreams[f].type;
                    if (j == undefined || "undefined" == j) {
                        var k = $(a + " " + h);
                        k.length > 1 ? k.each(function(a) {
                            var b = i.replace("[IDX]", a);
                            $(this).attr("data-clickstream", b) }) : k.attr("data-clickstream", i.replace("[IDX]", "0")) } else "onload" == j && (initCompleted ? saveClickStreamData(i) : aTracking.push(i)) }
            debugTiming && console.timeEnd("processTracking") }

    function savedClickstream() {}

    function saveClickStreamData(a) {
        var b = {};
        b.Call_vod__c = a;
        var c = JSON.stringify(b);
        request = "veeva:saveObject(Call_Clickstream_vod__c),value(" + c, request += "),callback(savedClickstream)", (!veeva.debug || (showDebug("[CLICKSTREAM]\r\nSaving clickstream obj: '" + a + "'\r\nrequest=" + request), veeva.runningOnVeeva)) && (document.location = request) }

    function isVeeva() {
        return /(iPad).*AppleWebKit/i.test(navigator.userAgent) }

    function showDebug(a) { console.log(a) }
    veeva.currentKeyMessage = "", veeva.currentPage = "", veeva.runningOnVeeva = isVeeva(), veeva.swipeOn = !0, veeva.disableSwipeOnVeeva = !1, veeva.swipeThreshold = 150, veeva.allowSamePageReload = !1, veeva.debug = !1, veeva.transitions = !0, veeva.slideTransitions = !0, veeva.swipeTypes = { DEFAULT: 0, VERTICAL: 1 }, veeva.goSlide = function(a) { processLink(a) }, veeva.goDirection = function(a) {
        if (a = a.toLowerCase(), "up" == a) a = "down";
        else if ("down" == a) a = "up";
        else if ("left" == a || "previous" == a) a = "right";
        else {
            if ("right" != a && "next" != a) return;
            a = "left" }
        processDirection(a) }, veeva.getNavDirections = function() {
        return getNavDirections() }, veeva.callClickstream = function(a) { saveClickStreamData(a) }, veeva.getClickEvent = function() {
        return clickEvent }, veeva.getPackageDefaultPage = function(a) {
        return getPackageDefaultPage(a) }, veeva.getSwipeType = function() {
        return swipeType }, veeva.getConfig = function() {
        return veevaConfigCopy }, veeva.onLeave = null;
    var veevaConfig = {},
        veevaConfigCopy = {},
        ssKey = "km_url",
        tceKey = "tranEntrance",
        pages = [],
        subpages = [],
        keymessages = [],
        currentPageIdx = 0,
        currentSubPageIdx = -1,
        currentKMIdx = 0,
        swipeType = veeva.swipeTypes.DEFAULT,
        transitionClassExit = "",
        transitionClassEntrance = "",
        initCompleted = !1,
        debugTiming = !1,
        clickEvent = isTouchDevice() ? "touchstart" : "click",
        $app;
    veeva.preinit = function() { debugTiming && console.time("veeva.preinit");
        var a = sessionStorage.getItem(ssKey);
        if ("" != a && "null" != a && null != a) return sessionStorage.setItem(ssKey, ""), document.location.href = a, void 0;
        try {
            var b = loadFile("global/js/veevaConfig.json", !0);
            veevaConfig = JSON.parse(b), veevaConfigCopy = JSON.parse(b) } catch (c) {
            return showDebug("[CONFIG]\r\nveevaConfig.json JSON PARSE ERROR:\r\n" + c), void 0 }
        var a = document.location.pathname.split("/");
        veeva.currentPage = a[a.length - 1], processPartials("body"), processTracking("body", veeva.currentPage), debugTiming && console.timeEnd("veeva.preinit") }, veeva.initStart = function() { debugTiming && console.time("veeva.initStart"), veeva.debug && showDebug("[INIT]\r\nveeva.initStart() called\r\nveeva.swipeOn = " + veeva.swipeOn + "\r\nveeva.allowSamePageReload = " + veeva.allowSamePageReload + "\r\nveeva.runningOnVeeva = " + veeva.runningOnVeeva + "\r\nveeva.transitions = " + veeva.transitions + "\r\nveeva.disableSwipeOnVeeva = " + veeva.disableSwipeOnVeeva + "\r\nveeva.slideTransitions = " + veeva.slideTransitions), $app = jQuery("#app"), veeva.disableSwipeOnVeeva && (veeva.slideTransitions = !1), veeva.transitions || $app.css({ "-webkit-transition": "none", transition: "none" }).addClass("active");
        var a = sessionStorage.getItem(tceKey);
        if ("" != a && "null" != a && null != a && (veeva.transitions && $app.addClass(a), sessionStorage.setItem(tceKey, "")), veeva.currentPage = getDefaultKeyMessagePage(veeva.currentPage.replace(".html", ".zip")), veeva.currentKeyMessage = getKeyMessage(veeva.currentPage), AddHooks("body"), setupPages(), swipeType == veeva.swipeTypes.VERTICAL) {
            for (var b = 0, c = subpages.length; c > b; b++)
                if (subpages[b] == veeva.currentPage) { currentSubPageIdx = b;
                    break }
            for (var d = getDefaultKeyMessagePage(veeva.currentKeyMessage), b = 0, c = pages.length; c > b; b++)
                if (pages[b] == d) { currentPageIdx = b;
                    break } } else
            for (var b = 0, c = pages.length; c > b; b++)
                if (pages[b] == veeva.currentPage) { currentPageIdx = b;
                    break } for (var b = 0, c = keymessages.length; c > b; b++)
            if (keymessages[b] == veeva.currentKeyMessage) { currentKMIdx = b;
                break }
        veeva.disableSwipeOnVeeva && veeva.runningOnVeeva && (veeva.swipeOn = !1), veeva.swipeOn ? $app.swipe({ swipeStatus: function(a, b, c) {
                if ("end" == b) {
                    if (swipeType == veeva.swipeTypes.DEFAULT && "left" != c && "right" != c) return;
                    processDirection(c) } }, triggerOnTouchEnd: !1, threshold: veeva.swipeThreshold }) : $app.swipe({ swipeStatus: function() {}, triggerOnTouchEnd: !1, threshold: veeva.swipeThreshold }), debugTiming && console.timeEnd("veeva.initStart") }, veeva.initEnd = function() {
        if (debugTiming && console.time("veeva.initEnd"), veeva.debug && showDebug("[INIT]\r\nveeva.initEnd() called"), veeva.transitions && setTimeout(function() { $app.removeClass().addClass("active") }, 250), veeva.debug && showDebug("[INIT]\r\nveeva.swipeOn = " + veeva.swipeOn), aTracking.length > 0) {
            for (var a = 0, b = aTracking.length; b > a; a++) saveClickStreamData(aTracking[a]);
            aTracking = new Array }
        initCompleted = !0, debugTiming && console.timeEnd("veeva.initEnd") }, veeva.bind = function(a, b) { debugTiming && console.time("veeva.bind"), veeva.debug && showDebug("[BIND]\r\nveeva.bind('" + a + "', '" + b + "') called"), processPartials(a);
        var c = b.split("/");
        b = c[c.length - 1].toLowerCase(), processTracking(a, b), AddHooks(a), debugTiming && console.timeEnd("veeva.bind") }, veeva.getPartialById = function(a) {
        for (var b in veevaConfig.partials)
            if (veevaConfig.partials[b].id == a) return veevaConfig.partials[b].content;
        return "" };
    var aTracking = new Array }(window.veeva = window.veeva || {}, jQuery), veeva.preinit();
