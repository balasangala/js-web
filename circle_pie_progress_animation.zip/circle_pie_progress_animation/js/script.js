/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


var clickHandler = "click";
$(document).ready(function () {
	setTimeout(function () {
		$("#wrapperImg1").css({
			"visibility": "hidden"
		});
	}, 0);
	$("#wrapper").css({
		"visibility": "visible"
	});

	$('#footer_icon1,#footer_icon2').bind('tap', function () {
		window.location.href = $(this).attr('goto');
	});
	
	$('#header').addClass('animated fadeInLeft');
	$('#sub_heading').addClass('animated fadeInRight');
	
	$('#label1').bind('tap', function () {

		$('#circle').circleProgress({
			value: 0.76,
			size: 276,
			startAngle: -0.078,
			thickness: 138,
			fill: {
				
				gradient: ["#682e7d"]
			}
		});

		$("#value1").delay(1100).fadeIn();
	

	});

	$('#label2').bind('tap', function () {

		$('#circle2').circleProgress({
			value: 0.13,
			size: 276,
			startAngle: -1.59,
			thickness: 138,
			fill: {
				color: "#9774a4"
			}
		});

		$("#value2").delay(1100).fadeIn();

	});


	$('#label3').bind('tap', function () {

		$('#circle3').circleProgress({
			value: 0.113,
			size: 276,
			startAngle: -0.78,
			thickness: 138,
			fill: {
				color: "#b39abc"
			}
		});

		$("#value3").delay(1100).fadeIn();

	});


});
