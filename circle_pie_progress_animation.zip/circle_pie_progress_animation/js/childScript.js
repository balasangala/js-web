var clickHandler = 'click';
var currentSlide=0;
$(document).ready(function() {
    if ('ontouchstart' in document.documentElement) {
        clickHandler = "touchstart";
    }
    $("body").bind('touchmove', function(event) {
        event.preventDefault()
    });
    $(document).swipe({
        swipe: function(event, direction, distance, duration, fingerCount) {
            //This only fires when the user swipes left
            // var closestViewport = $(event.target).closest('.content');
				if (!$(event.target).hasClass('dragable_icon') && !$(event.target).hasClass('ui-draggable') && !$(event.target).hasClass('noSwipe')) {
				if (direction == 'up') {
				   
						if (parent.pageNo < parent.totalPage) {
							parent.pageNo++;
							setTimeout(function() {
								parent.loadPage();
							}, 100);
	
						}
					
				} else if (direction == 'down') {
					
						if (parent.pageNo > 1) {
							parent.pageNo--;
							setTimeout(function() {
								parent.loadPage();
							}, 100);
						}
				
			       
                }else if (direction == 'left') {
                        document.location="veeva:gotoSlide(ZE_Slide02.zip,	EUPP_SouthAfrica_Symbicort_iDA)";
                }else if (direction == 'right') {
//                        document.location="veeva:gotoSlide(.zip,)";
                	
                    
                }
            }

        }
    });
});