function Book(title, author, year){
    this.title = title;
    this.author =author
    this.year = year;
}
Book.prototype.getSummary = function(){
    return `${this.title} was written by ${this.author} in ${this.year}`;
}

//Inheritance

//magzine constructor
function Magzine(title, author, year, month){
    Book.call(this, title, author,year);
    this.month = month;

}

//Inherit prototype method
Magzine.prototype = Object.create(Book.prototype);

var mag1 = new Magzine("mag1","arun", 2018, "june");
console.log(mag1);
//It will work only whenc method is inherited
console.log(mag1.getSummary());

//use magzine constructor
Magzine.prototype.constructor = Magzine;
