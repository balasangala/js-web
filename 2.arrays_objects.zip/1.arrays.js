//spice() method in arrays
//var arr = ["str1", "str2", "str3", "str4"];
// document.write(arr.splice());//empty 
// document.write(arr);//str1,str2,str3,str4

// document.write(arr.splice(0));//str1,str2,str3,str4(it removes all elements & containing all removed elements)
// document.write(arr);//(output is empty bcas all elemets are removed)

// document.write(arr.splice(1));//str2,str3,str4(it starts removing from position one);
// document.write(arr);//str1(it is only element left in array);

// document.write(arr.splice(0,1));//str1(position starts from 0 & removes one element)
// 0 represents star position where elements should be added, 1 represents how many elements should be removed
// document.write(arr);//str2,str3,str4(rest elements)

// document.write(arr.splice(1, 2));//str2,str3
// document.write(arr);//st1,str4

// adding elements

// document.write(arr.splice(0,0,"str5"));//empty(bcas ur adding elements)
// document.write(arr)//str5,str1,str2,str3,str4

// document.write(arr.splice(1,"str5"));//empty(bcas you must include 0 elements to be removed)
// document.write(arr);//str1,str2,str3,str4

// document.write(arr.splice(1,0,"str5"));//empty(bcas ur adding elements)
// document.write(arr)//str1,str5,str2,str3,str4


//slice() method in arrays

// var arr = ["str1", "str2", "str3", "str4"];
// document.write(arr.slice());//st1,str2,str3,st4
// document.write(arr);//st1,str2,str3,st4(never effect original array)
// document.write(arr.slice(0));//st1,str2,str3,st4(it will strat extracting elements from index position 0);
// document.write(arr);//st1,str2,str3,st4(never effect original array)

// document.write(arr.slice(1));//str2,str3,str4(extracting elements from index position 1 );
// document.write(arr);//st1,str2,str3,st4(never effect original array)

// document.write(arr.slice(0,1));//str1
// 0 represents where to start selection 1 represents where to end selection
// document.write(arr.slice(1,1));// empty(start & end positions can not be same);
// document.write(arr.slice(1,2));//str2
// document.write(arr.slice(0,2));//str1,str3

//sort() method;

//By default, the sort() function sorts values as strings.
//This works well for strings ("paytm" comes before "phonepay").
// var arr = ["zeta", "paytm", "tez", "phonepay"];
// document.write(arr.sort());//paytm,phonepay,tez,zeta

// var arr = [40, 100, 1, 5, 25, 10];
// document.write(arr.sort());//1,10,100,25,40,5
//However, if numbers are sorted as strings, "25" is bigger than "100", because "2" is bigger than "1".

// arr.sort(comparefunc);

// function comparefunc(a, b){
// 	return a-b;
// }

// document.write(arr);//1,5,10,25,40,100
// u can also find min & max number by using index position
// document.write(arr[0]);//1
// document.write(arr[arr.length-1]);//100

//Use the same trick to sort an array descending:
// arr.sort(comparefunc);

// function comparefunc(a, b){
// 	return b-a;
// }

// document.write(arr);//100,40,25,10,5,1