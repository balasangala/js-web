class Book {
    constructor(title, author, year){
        this.title = title;
        this.author = author;
        this.year = year;
    }
//method
    getSummary(){
        return `${this.title} was written by ${this.author} in ${this.year}`;
    }

    //changing properties
    changeYear(newYear){
      this.year = newYear;
    }

    //stati method
    static topBooks(){
        return `my books`;
    }
}




const book1 = new Book("BOOK ONE", "balu", 2018);

console.log(book1.getSummary());

book1.changeYear("2000");
console.log(book1);

console.log(Book.topBooks());