//Prototype
//All JavaScript objects inherit properties and methods from a prototype.
//The Object.prototype is on the top of the prototype inheritance chain:

//Sometimes you want to add new properties (or methods) to all existing objects of a given type.
//Sometimes you want to add new properties (or methods) to an object constructor.	

//The JavaScript prototype property allows you to add new properties & methods to object constructors:


//constructor 
function Book(title2, author, year){
	this.title1 = title2;
	this.author = author;	
	this.year = year;
	
}

//creating objects
var book1 = new Book("Book1", "balu", "2015");
var book2 = new Book("Book2", "bal2", "2016");

//adding property to constructor using prototype propery
// Book.prototype.country = "india";
// console.log(book1.country);

//adding method to constructor using prototype propery
Book.prototype.getSummary = function(){
	return `${this.title1} was written by ${this.author} from ${this.country}`;
}
console.log(book1.getSummary());
// console.log(book2.getSummary());

Book.prototype.geAge = function(){
	const years = new Date().getFullYear()-this.year;
	return `${this.title1} is ${years} old`;
}

console.log(book1.geAge());

//changign the data

Book.prototype.revise = function(newYear){
	this.year = newYear;
	this.revised = true;
}

book1.revise("2018");
console.log(book1);





