
//using object creat 
const Bookprotos = {
    getSummary: function(){
        return `${this.title} was written by ${this.author} in ${this.year}`;
    }
}

// const book1 = Object.create(Bookprotos);
// book1.title = "Book one";
// book1.author = "Balu";
// book1.year = 2019;

const book1 = Object.create(Bookprotos, {
    title : { value : "Book one"},
    author : { value : "sangal"},
    year : { value : 2018}

})

console.log(book1.getSummary());